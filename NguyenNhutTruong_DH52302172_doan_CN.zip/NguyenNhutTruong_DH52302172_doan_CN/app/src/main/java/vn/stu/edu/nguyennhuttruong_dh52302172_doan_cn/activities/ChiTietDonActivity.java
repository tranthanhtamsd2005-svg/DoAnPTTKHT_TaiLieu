package vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.activities;

import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.R;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.models.DonHang;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.repositories.WorkerRepository;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.utils.SessionManager;

public class ChiTietDonActivity extends AppCompatActivity {

    public static final String EXTRA_MA_DON = "extra_ma_don";

    private ProgressBar pbChiTiet;
    private LinearLayout layoutLoi, layoutNoiDung;
    private TextView tvLoi;
    private TextView tvMaDon, tvTrangThai, tvDichVu, tvKhachHang, tvDiaChi,
            tvMoTa, tvThoiGian, tvGiaThamKhao, tvBaoHanh, tvLichSu;
    private Button btnNhapEta, btnBatDauDiChuyen, btnDaDenNoi, btnBatDauLam, btnHoanThanhDon;

    private WorkerRepository repo;
    private String maTho;
    private String maDon;
    private DonHang donHienTai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chi_tiet_don);

        SessionManager session = new SessionManager(this);
        maTho = session.getMaTho();
        maDon = getIntent().getStringExtra(EXTRA_MA_DON);

        if (maTho == null || maDon == null) {
            finish();
            return;
        }

        repo = new WorkerRepository();
        pbChiTiet = findViewById(R.id.pbChiTiet);
        layoutLoi = findViewById(R.id.layoutLoiChiTiet);
        layoutNoiDung = findViewById(R.id.layoutNoiDungChiTiet);
        tvLoi = findViewById(R.id.tvLoiChiTiet);

        tvMaDon = findViewById(R.id.tvCtMaDon);
        tvTrangThai = findViewById(R.id.tvCtTrangThai);
        tvDichVu = findViewById(R.id.tvCtDichVu);
        tvKhachHang = findViewById(R.id.tvCtKhachHang);
        tvDiaChi = findViewById(R.id.tvCtDiaChi);
        tvMoTa = findViewById(R.id.tvCtMoTa);
        tvThoiGian = findViewById(R.id.tvCtThoiGian);
        tvGiaThamKhao = findViewById(R.id.tvCtGiaThamKhao);
        tvBaoHanh = findViewById(R.id.tvCtBaoHanh);
        tvLichSu = findViewById(R.id.tvCtLichSu);

        btnNhapEta = findViewById(R.id.btnNhapEta);
        btnBatDauDiChuyen = findViewById(R.id.btnBatDauDiChuyen);
        btnDaDenNoi = findViewById(R.id.btnDaDenNoi);
        btnBatDauLam = findViewById(R.id.btnBatDauLam);
        btnHoanThanhDon = findViewById(R.id.btnHoanThanhDon);

        findViewById(R.id.btnThuLaiChiTiet).setOnClickListener(v -> taiChiTiet());

        btnNhapEta.setOnClickListener(v -> moHopThoaiEta());
        btnBatDauDiChuyen.setOnClickListener(v -> capNhatHanhTrinh("DANG_DI_CHUYEN"));
        btnDaDenNoi.setOnClickListener(v -> capNhatHanhTrinh("DA_DEN_NOI"));
        btnBatDauLam.setOnClickListener(v -> xacNhanBatDauLam());
        btnHoanThanhDon.setOnClickListener(v -> xacNhanHoanThanh());

        taiChiTiet();
    }

    private void taiChiTiet() {
        pbChiTiet.setVisibility(View.VISIBLE);
        layoutLoi.setVisibility(View.GONE);
        layoutNoiDung.setVisibility(View.GONE);

        repo.chiTietDon(maTho, maDon, new WorkerRepository.KetQua<DonHang>() {
            @Override
            public void thanhCong(DonHang don) {
                pbChiTiet.setVisibility(View.GONE);
                layoutNoiDung.setVisibility(View.VISIBLE);
                donHienTai = don;
                hienThiThongTin(don);
            }

            @Override
            public void loi(String thongBao) {
                pbChiTiet.setVisibility(View.GONE);
                layoutLoi.setVisibility(View.VISIBLE);
                tvLoi.setText(thongBao);
            }
        });
    }

    private void hienThiThongTin(DonHang don) {
        tvMaDon.setText("Mã đơn: " + don.getMaDon());
        String tienDoText = don.getTienDo() != null ? " | Hành trình: " + don.getTienDo() : "";
        tvTrangThai.setText("Trạng thái: " + don.getTrangThai() + tienDoText);

        String tenDv = don.getTenDichVu() != null ? don.getTenDichVu() : don.getMaDichVu();
        String tenKv = don.getTenKhuVuc() != null ? don.getTenKhuVuc() : don.getMaKhuVuc();
        tvDichVu.setText("Dịch vụ: " + tenDv + " (" + tenKv + ")");
        tvKhachHang.setText("Khách hàng: " + (don.getTenKhach() != null ? don.getTenKhach() : "--"));
        tvDiaChi.setText("Địa chỉ: " + (don.getDiaChiChiTiet() != null ? don.getDiaChiChiTiet() : "--"));
        tvMoTa.setText("Mô tả sự cố: " + (don.getMoTa() != null ? don.getMoTa() : "--"));

        StringBuilder tg = new StringBuilder();
        tg.append("Hình thức: ").append(don.getHinhThucDat());
        if (don.getGioHen() != null) tg.append(" | Hẹn: ").append(don.getGioHen());
        if (don.getGioDuKienDen() != null) tg.append("\nETA dự kiến: ").append(don.getGioDuKienDen());
        if (don.getNgayNhan() != null) tg.append("\nĐã nhận lúc: ").append(don.getNgayNhan());
        if (don.getNgayBatDauLam() != null) tg.append("\nBắt đầu làm: ").append(don.getNgayBatDauLam());
        if (don.getNgayHoanThanh() != null) tg.append("\nHoàn thành: ").append(don.getNgayHoanThanh());
        tvThoiGian.setText(tg.toString());

        NumberFormat nf = NumberFormat.getInstance(new Locale("vi", "VN"));
        String giaMin = don.getGiaThapNhatApDung() != null ? nf.format(don.getGiaThapNhatApDung()) : "0";
        String giaMax = don.getGiaCaoNhatApDung() != null ? nf.format(don.getGiaCaoNhatApDung()) : "0";
        tvGiaThamKhao.setText("Giá tham khảo: " + giaMin + "đ - " + giaMax + "đ (chưa gồm vật tư)");

        if (don.getHanBaoHanh() != null) {
            tvBaoHanh.setText("Hạn bảo hành đến: " + don.getHanBaoHanh());
        } else if (don.getBaoHanhGioApDung() != null && don.getBaoHanhGioApDung() > 0) {
            tvBaoHanh.setText("Chính sách bảo hành: " + don.getBaoHanhGioApDung() + " giờ sau khi hoàn thành");
        } else {
            tvBaoHanh.setText("Bảo hành: Tiếp nhận phản ánh theo chính sách dịch vụ");
        }

        List<DonHang.LichSuTrangThai> ls = don.getLichSuTrangThai();
        if (ls == null || ls.isEmpty()) {
            tvLichSu.setText("Chưa có lịch sử cập nhật.");
        } else {
            StringBuilder sb = new StringBuilder();
            for (DonHang.LichSuTrangThai item : ls) {
                sb.append("• [").append(item.getNgayThayDoi()).append("] ")
                        .append(item.getTrangThaiCu() != null ? item.getTrangThaiCu() + " → " : "")
                        .append(item.getTrangThaiMoi());
                if (item.getGhiChu() != null && !item.getGhiChu().isEmpty()) {
                    sb.append(" (").append(item.getGhiChu()).append(")");
                }
                sb.append("\n");
            }
            tvLichSu.setText(sb.toString().trim());
        }

        capNhatNutTheoTrangThai(don);
    }

    private void capNhatNutTheoTrangThai(DonHang don) {
        btnNhapEta.setVisibility(View.GONE);
        btnBatDauDiChuyen.setVisibility(View.GONE);
        btnDaDenNoi.setVisibility(View.GONE);
        btnBatDauLam.setVisibility(View.GONE);
        btnHoanThanhDon.setVisibility(View.GONE);

        String tt = don.getTrangThai();
        String tienDo = don.getTienDo();

        if ("DA_NHAN".equals(tt)) {
            btnNhapEta.setVisibility(View.VISIBLE);
            btnNhapEta.setText(don.getGioDuKienDen() != null
                    ? "Cập nhật lại ETA" : "Báo giờ dự kiến đến (ETA)");

            if ("DANG_DI_CHUYEN".equals(tienDo)) {
                btnDaDenNoi.setVisibility(View.VISIBLE);
            } else if (!"DA_DEN_NOI".equals(tienDo)) {
                btnBatDauDiChuyen.setVisibility(View.VISIBLE);
            }

            btnBatDauLam.setVisibility(View.VISIBLE);
        } else if ("DANG_LAM".equals(tt)) {
            btnHoanThanhDon.setVisibility(View.VISIBLE);
        }
    }

    private void moHopThoaiEta() {
        boolean daCoEtaCu = donHienTai != null && donHienTai.getGioDuKienDen() != null;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(48, 24, 48, 8);

        EditText edtPhut = new EditText(this);
        edtPhut.setHint("Số phút nữa tới nơi (vd: 30)");
        edtPhut.setInputType(InputType.TYPE_CLASS_NUMBER);
        box.addView(edtPhut);

        EditText edtLyDo = new EditText(this);
        edtLyDo.setHint(daCoEtaCu ? "Lý do đổi giờ (bắt buộc)" : "Ghi chú (không bắt buộc)");
        box.addView(edtLyDo);

        new AlertDialog.Builder(this)
                .setTitle("Báo giờ dự kiến đến (ETA)")
                .setView(box)
                .setPositiveButton("Xác nhận", (d, w) -> {
                    String phutStr = edtPhut.getText().toString().trim();
                    if (phutStr.isEmpty()) {
                        Toast.makeText(this, "Vui lòng nhập số phút", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    int phut;
                    try {
                        phut = Integer.parseInt(phutStr);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Số phút không hợp lệ", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    String lyDo = edtLyDo.getText().toString().trim();
                    if (daCoEtaCu && lyDo.isEmpty()) {
                        Toast.makeText(this, "Đổi ETA bắt buộc nhập lý do", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    pbChiTiet.setVisibility(View.VISIBLE);
                    repo.capNhatEta(maTho, maDon, phut, lyDo, new WorkerRepository.KetQua<String>() {
                        @Override
                        public void thanhCong(String msg) {
                            Toast.makeText(ChiTietDonActivity.this, msg, Toast.LENGTH_SHORT).show();
                            taiChiTiet();
                        }

                        @Override
                        public void loi(String thongBao) {
                            Toast.makeText(ChiTietDonActivity.this, thongBao, Toast.LENGTH_LONG).show();
                            taiChiTiet();
                        }
                    });
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    private void capNhatHanhTrinh(String tienDoMoi) {
        pbChiTiet.setVisibility(View.VISIBLE);
        repo.capNhatHanhTrinh(maTho, maDon, tienDoMoi, new WorkerRepository.KetQua<String>() {
            @Override
            public void thanhCong(String msg) {
                Toast.makeText(ChiTietDonActivity.this, msg, Toast.LENGTH_SHORT).show();
                taiChiTiet();
            }

            @Override
            public void loi(String thongBao) {
                Toast.makeText(ChiTietDonActivity.this, thongBao, Toast.LENGTH_LONG).show();
                taiChiTiet();
            }
        });
    }

    private void xacNhanBatDauLam() {
        new AlertDialog.Builder(this)
                .setTitle("Bắt đầu làm")
                .setMessage("Xác nhận chuyển đơn " + maDon + " sang Đang làm?")
                .setPositiveButton("Đồng ý", (d, w) -> {
                    btnBatDauLam.setEnabled(false);
                    pbChiTiet.setVisibility(View.VISIBLE);
                    repo.batDauLam(maTho, maDon, new WorkerRepository.KetQua<String>() {
                        @Override
                        public void thanhCong(String msg) {
                            btnBatDauLam.setEnabled(true);
                            Toast.makeText(ChiTietDonActivity.this, msg, Toast.LENGTH_SHORT).show();
                            taiChiTiet();
                        }

                        @Override
                        public void loi(String thongBao) {
                            btnBatDauLam.setEnabled(true);
                            Toast.makeText(ChiTietDonActivity.this, thongBao, Toast.LENGTH_LONG).show();
                            taiChiTiet();
                        }
                    });
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    private void xacNhanHoanThanh() {
        new AlertDialog.Builder(this)
                .setTitle("Hoàn thành đơn")
                .setMessage("Xác nhận bạn đã làm xong đơn " + maDon + "?")
                .setPositiveButton("Hoàn thành", (d, w) -> {
                    btnHoanThanhDon.setEnabled(false);
                    pbChiTiet.setVisibility(View.VISIBLE);
                    repo.hoanThanhDon(maTho, maDon, new WorkerRepository.KetQua<String>() {
                        @Override
                        public void thanhCong(String msg) {
                            btnHoanThanhDon.setEnabled(true);
                            Toast.makeText(ChiTietDonActivity.this, msg, Toast.LENGTH_SHORT).show();
                            taiChiTiet();
                        }

                        @Override
                        public void loi(String thongBao) {
                            btnHoanThanhDon.setEnabled(true);
                            Toast.makeText(ChiTietDonActivity.this, thongBao, Toast.LENGTH_LONG).show();
                            taiChiTiet();
                        }
                    });
                })
                .setNegativeButton("Hủy", null)
                .show();
    }
}