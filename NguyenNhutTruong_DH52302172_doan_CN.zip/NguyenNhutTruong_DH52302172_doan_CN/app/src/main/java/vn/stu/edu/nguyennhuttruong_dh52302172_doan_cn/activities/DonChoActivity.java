package vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.R;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.adapters.DonChoAdapter;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.models.DonHang;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.repositories.WorkerRepository;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.utils.SessionManager;

public class DonChoActivity extends AppCompatActivity {

    private ProgressBar progressBar;
    private TextView tvThongBao;
    private RecyclerView rvDonCho;
    private DonChoAdapter adapter;

    private WorkerRepository repo;
    private String maTho;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_don_cho);

        maTho = new SessionManager(this).getMaTho();
        if (maTho == null || maTho.trim().isEmpty()) {
            finish();
            return;
        }

        repo = new WorkerRepository();

        Button btnQuayLai = findViewById(R.id.btnQuayLai);
        Button btnTaiLai = findViewById(R.id.btnTaiLai);
        progressBar = findViewById(R.id.progressBar);
        tvThongBao = findViewById(R.id.tvThongBao);
        rvDonCho = findViewById(R.id.rvDonCho);

        adapter = new DonChoAdapter(new DonChoAdapter.OnDonChoClickListener() {
            @Override
            public void onNhanDon(DonHang donHang) {
                Toast.makeText(DonChoActivity.this,
                        "Bước 2 sẽ gọi API Nhận đơn: " + donHang.getMaDon(),
                        Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onTuChoi(DonHang donHang) {
                Toast.makeText(DonChoActivity.this,
                        "Bước 2 sẽ gọi API Từ chối đơn: " + donHang.getMaDon(),
                        Toast.LENGTH_SHORT).show();
            }
        });

        rvDonCho.setLayoutManager(new LinearLayoutManager(this));
        rvDonCho.setAdapter(adapter);

        btnQuayLai.setOnClickListener(v -> finish());
        btnTaiLai.setOnClickListener(v -> taiDanhSachDonCho());
    }

    @Override
    protected void onResume() {
        super.onResume();
        taiDanhSachDonCho();
    }

    private void taiDanhSachDonCho() {
        progressBar.setVisibility(View.VISIBLE);
        tvThongBao.setVisibility(View.GONE);
        rvDonCho.setVisibility(View.GONE);

        repo.donCho(maTho, new WorkerRepository.KetQua<List<DonHang>>() {
            @Override
            public void thanhCong(List<DonHang> ds) {
                progressBar.setVisibility(View.GONE);
                if (ds == null || ds.isEmpty()) {
                    tvThongBao.setText("Hiện chưa có đơn chờ phù hợp kỹ năng và khu vực của bạn.");
                    tvThongBao.setVisibility(View.VISIBLE);
                    rvDonCho.setVisibility(View.GONE);
                } else {
                    adapter.capNhatDanhSach(ds);
                    tvThongBao.setVisibility(View.GONE);
                    rvDonCho.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void loi(String tb) {
                progressBar.setVisibility(View.GONE);
                tvThongBao.setText("Lỗi tải đơn chờ: " + tb + "\nNhấn \"Tải lại\" để thử lại.");
                tvThongBao.setVisibility(View.VISIBLE);
                rvDonCho.setVisibility(View.GONE);
            }
        });
    }
}