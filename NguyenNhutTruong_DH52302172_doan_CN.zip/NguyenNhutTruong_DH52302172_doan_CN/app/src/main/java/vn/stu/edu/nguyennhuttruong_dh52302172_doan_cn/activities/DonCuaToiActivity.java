package vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.R;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.adapters.DonCuaToiAdapter;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.models.DonHang;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.repositories.WorkerRepository;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.utils.SessionManager;

public class DonCuaToiActivity extends AppCompatActivity {

    private ProgressBar pbDonCuaToi;
    private TextView tvTrangThai;
    private RecyclerView rvDonCuaToi;
    private DonCuaToiAdapter adapter;
    private WorkerRepository repo;
    private String maTho;
    private String trangThaiLoc = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_don_cua_toi);

        SessionManager session = new SessionManager(this);
        maTho = session.getMaTho();
        if (maTho == null || maTho.isEmpty()) {
            finish();
            return;
        }

        repo = new WorkerRepository();
        pbDonCuaToi = findViewById(R.id.pbDonCuaToi);
        tvTrangThai = findViewById(R.id.tvTrangThaiDonCuaToi);
        rvDonCuaToi = findViewById(R.id.rvDonCuaToi);

        adapter = new DonCuaToiAdapter(don -> {
            Intent intent = new Intent(DonCuaToiActivity.this, ChiTietDonActivity.class);
            intent.putExtra(ChiTietDonActivity.EXTRA_MA_DON, don.getMaDon());
            startActivity(intent);
        });

        rvDonCuaToi.setLayoutManager(new LinearLayoutManager(this));
        rvDonCuaToi.setAdapter(adapter);

        Button btnTaiLai = findViewById(R.id.btnTaiLaiDonCuaToi);
        btnTaiLai.setOnClickListener(v -> taiDanhSach());

        findViewById(R.id.btnLocTatCa).setOnClickListener(v -> {
            trangThaiLoc = "";
            taiDanhSach();
        });
        findViewById(R.id.btnLocDaNhan).setOnClickListener(v -> {
            trangThaiLoc = "DA_NHAN";
            taiDanhSach();
        });
        findViewById(R.id.btnLocDangLam).setOnClickListener(v -> {
            trangThaiLoc = "DANG_LAM";
            taiDanhSach();
        });
        findViewById(R.id.btnLocHoanThanh).setOnClickListener(v -> {
            trangThaiLoc = "HOAN_THANH";
            taiDanhSach();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        taiDanhSach();
    }

    private void taiDanhSach() {
        pbDonCuaToi.setVisibility(View.VISIBLE);
        tvTrangThai.setVisibility(View.GONE);

        repo.donCuaToi(maTho, trangThaiLoc.isEmpty() ? null : trangThaiLoc,
                new WorkerRepository.KetQua<List<DonHang>>() {
                    @Override
                    public void thanhCong(List<DonHang> duLieu) {
                        pbDonCuaToi.setVisibility(View.GONE);
                        adapter.capNhatDanhSach(duLieu);
                        if (duLieu == null || duLieu.isEmpty()) {
                            tvTrangThai.setText("Chưa có đơn hàng nào");
                            tvTrangThai.setVisibility(View.VISIBLE);
                        }
                    }

                    @Override
                    public void loi(String thongBao) {
                        pbDonCuaToi.setVisibility(View.GONE);
                        tvTrangThai.setText(thongBao);
                        tvTrangThai.setVisibility(View.VISIBLE);
                    }
                });
    }
}