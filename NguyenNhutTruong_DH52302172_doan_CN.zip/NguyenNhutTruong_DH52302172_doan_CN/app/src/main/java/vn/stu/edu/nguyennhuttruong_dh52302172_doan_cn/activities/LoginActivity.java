package vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.R;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.utils.ApiService;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.utils.RetrofitClient;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.utils.SessionManager;

public class LoginActivity extends AppCompatActivity {

    private EditText edtPhone, edtPassword;
    private Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edtPhone = findViewById(R.id.edtPhone);
        edtPassword = findViewById(R.id.edtPassword);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(v -> {
            String username = edtPhone.getText().toString().trim();
            String password = edtPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Vui lòng nhập đủ thông tin", Toast.LENGTH_SHORT).show();
                return;
            }

            btnLogin.setEnabled(false);
            btnLogin.setText("Đang đăng nhập...");

            Map<String, String> body = new HashMap<>();
            body.put("tenDangNhap", username);
            body.put("matKhau", password);

            ApiService apiService = RetrofitClient.getApiService();
            apiService.login(body).enqueue(new Callback<Map<String, Object>>() {
                @Override
                public void onResponse(Call<Map<String, Object>> call, Response<Map<String, Object>> response) {
                    btnLogin.setEnabled(true);
                    btnLogin.setText("Đăng Nhập");

                    if (response.isSuccessful() && response.body() != null) {
                        Object statusObj = response.body().get("status");
                        String status = statusObj != null ? statusObj.toString() : "";

                        if ("success".equals(status)) {
                            Object maObj = response.body().get("maTaiKhoan");
                            if (maObj == null) maObj = response.body().get("ma_tai_khoan");
                            String maTho = maObj != null ? maObj.toString().trim() : "";

                            if (maTho.isEmpty()) {
                                hienLoi("Server trả success nhưng thiếu maTaiKhoan.\nBody: " + response.body());
                                return;
                            }

                            new SessionManager(LoginActivity.this).saveMaTho(maTho);
                            Toast.makeText(LoginActivity.this, "Đăng nhập thành công!", Toast.LENGTH_SHORT).show();

                            startActivity(new Intent(LoginActivity.this, MainActivity.class));
                            finish();
                        } else {
                            hienLoi("Đăng nhập không thành công.\nServer trả về: " + response.body());
                        }
                    } else {
                        hienLoi("Lỗi Server HTTP " + response.code() + "\nURL: " + call.request().url());
                    }
                }

                @Override
                public void onFailure(Call<Map<String, Object>> call, Throwable t) {
                    btnLogin.setEnabled(true);
                    btnLogin.setText("Đăng Nhập");
                    hienLoi("Không kết nối được tới:\n" + call.request().url() + "\n\nChi tiết: " + t.getMessage());
                }
            });
        });
    }

    private void hienLoi(String noiDung) {
        if (!isFinishing()) {
            new AlertDialog.Builder(LoginActivity.this)
                    .setTitle("Thông báo đăng nhập")
                    .setMessage(noiDung)
                    .setPositiveButton("Đóng", null)
                    .show();
        }

    }
}