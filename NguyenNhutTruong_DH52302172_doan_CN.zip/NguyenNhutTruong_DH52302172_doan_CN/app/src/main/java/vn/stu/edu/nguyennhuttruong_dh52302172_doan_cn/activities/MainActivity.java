package vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import java.util.Map;

import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.R;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.models.Tho;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.repositories.WorkerRepository;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.utils.SessionManager;

public class MainActivity extends AppCompatActivity {

    private TextView tvWelcome, tvTrangThai;
    private SwitchCompat swSanSang;
    private Button btnXemDonCho;

    private SessionManager session;
    private WorkerRepository repo;
    private String maTho;
    private boolean dangCapNhatUI = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        session = new SessionManager(this);
        maTho = session.getMaTho();
        if (maTho == null || maTho.trim().isEmpty()) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        repo = new WorkerRepository();

        // Đúng 4 ID trong activity_main.xml ở Bước 1
        tvWelcome = findViewById(R.id.tvWelcome);
        tvTrangThai = findViewById(R.id.tvTrangThai);
        swSanSang = findViewById(R.id.swSanSang);
        btnXemDonCho = findViewById(R.id.btnXemDonCho);

        tvWelcome.setText("Xin chào Thợ: " + maTho);
        swSanSang.setEnabled(false);
        btnXemDonCho.setEnabled(false);

        swSanSang.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (dangCapNhatUI) return;
            swSanSang.setEnabled(false);
            repo.sanSang(maTho, isChecked, new WorkerRepository.KetQua<>() {
                @Override
                public void thanhCong(Map<String, Object> du) {
                    swSanSang.setEnabled(true);
                    capNhatTrangThaiSanSang(isChecked);
                }

                @Override
                public void loi(String tb) {
                    dangCapNhatUI = true;
                    swSanSang.setChecked(!isChecked);
                    dangCapNhatUI = false;
                    swSanSang.setEnabled(true);
                    capNhatTrangThaiSanSang(!isChecked);
                    Toast.makeText(MainActivity.this, tb, Toast.LENGTH_SHORT).show();
                }
            });
        });

        btnXemDonCho.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DonChoActivity.class);
            startActivity(intent);
        });
        Button btnDonCuaToi = findViewById(R.id.btnDonCuaToi);
        btnDonCuaToi.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, DonCuaToiActivity.class))
        );
    }

    @Override
    protected void onResume() {
        super.onResume();
        taiHoSoTho();
    }

    private void taiHoSoTho() {
        repo.hoSo(maTho, new WorkerRepository.KetQua<>() {
            @Override
            public void thanhCong(Tho tho) {
                if (tho == null) return;

                String ten = (tho.getHoTen() != null && !tho.getHoTen().isEmpty())
                        ? tho.getHoTen() : maTho;
                tvWelcome.setText("Xin chào Thợ: " + ten);

                boolean tkHoatDong = "HOAT_DONG".equals(tho.getTrangThaiTaiKhoan());
                boolean daDuyet = "DA_DUYET".equals(tho.getTrangThaiDuyet());

                if (!tkHoatDong) {
                    tvTrangThai.setText("Trạng thái: Tài khoản đang bị khóa");
                    tvTrangThai.setTextColor(Color.parseColor("#D32F2F"));
                    swSanSang.setEnabled(false);
                    btnXemDonCho.setEnabled(false);
                } else if (!daDuyet) {
                    tvTrangThai.setText("Trạng thái: Hồ sơ chưa duyệt (" + tho.getTrangThaiDuyet() + ")");
                    tvTrangThai.setTextColor(Color.parseColor("#EF6C00"));
                    swSanSang.setEnabled(false);
                    btnXemDonCho.setEnabled(false);
                } else {
                    swSanSang.setEnabled(true);
                    capNhatTrangThaiSanSang(tho.isTrangThaiSanSang());
                }

                dangCapNhatUI = true;
                swSanSang.setChecked(tho.isTrangThaiSanSang());
                dangCapNhatUI = false;
            }

            @Override
            public void loi(String tb) {
                Toast.makeText(MainActivity.this, "Lỗi tải hồ sơ: " + tb, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void capNhatTrangThaiSanSang(boolean sanSang) {
        if (sanSang) {
            tvTrangThai.setText("Trạng thái: Đang sẵn sàng");
            tvTrangThai.setTextColor(Color.parseColor("#2E7D32"));
            btnXemDonCho.setEnabled(true);
        } else {
            tvTrangThai.setText("Trạng thái: Đang nghỉ");
            tvTrangThai.setTextColor(Color.parseColor("#D32F2F"));
            btnXemDonCho.setEnabled(false);
        }
    }
}