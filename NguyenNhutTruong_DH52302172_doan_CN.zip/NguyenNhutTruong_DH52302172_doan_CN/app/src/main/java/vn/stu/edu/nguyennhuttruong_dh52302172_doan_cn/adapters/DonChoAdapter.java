package vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.adapters;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.R;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;


import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.models.DonHang;

public class DonChoAdapter extends RecyclerView.Adapter<DonChoAdapter.DonChoViewHolder> {

    public interface OnDonChoClickListener {
        void onNhanDon(DonHang donHang);
        void onTuChoi(DonHang donHang);
    }

    private final List<DonHang> danhSach = new ArrayList<>();
    private final OnDonChoClickListener listener;
    private final NumberFormat nf = NumberFormat.getInstance(new Locale("vi", "VN"));

    public DonChoAdapter(OnDonChoClickListener listener) {
        this.listener = listener;
    }

    public void capNhatDanhSach(List<DonHang> dsMoi) {
        danhSach.clear();
        if (dsMoi != null) {
            danhSach.addAll(dsMoi);
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public DonChoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_don_cho, parent, false);
        return new DonChoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DonChoViewHolder holder, int position) {
        DonHang don = danhSach.get(position);

        holder.tvMaDon.setText("Mã đơn: " + anToan(don.getMaDon()));
        holder.tvTenDichVu.setText(anToan(don.getTenDichVu()));
        holder.tvTenKhuVuc.setText("Khu vực: " + anToan(don.getTenKhuVuc()));

        if ("HEN_GIO".equals(don.getHinhThucDat()) && don.getGioHen() != null) {
            holder.tvThoiGian.setText("Hẹn giờ: " + don.getGioHen());
        } else {
            holder.tvThoiGian.setText("Hình thức: Đặt ngay");
        }

        String giaMin = dinhDangTien(don.getGiaThapNhatApDung());
        String giaMax = dinhDangTien(don.getGiaCaoNhatApDung());
        holder.tvKhoangGia.setText("Giá tham khảo: " + giaMin + " - " + giaMax + " (chưa gồm vật tư)");

        holder.btnNhanDon.setOnClickListener(v -> {
            if (listener != null) listener.onNhanDon(don);
        });
        holder.btnTuChoi.setOnClickListener(v -> {
            if (listener != null) listener.onTuChoi(don);
        });
    }

    @Override
    public int getItemCount() {
        return danhSach.size();
    }

    private String dinhDangTien(BigDecimal tien) {
        if (tien == null) return "0 đ";
        return nf.format(tien) + " đ";
    }

    private String anToan(String s) {
        return s != null ? s : "";
    }

    static class DonChoViewHolder extends RecyclerView.ViewHolder {
        TextView tvMaDon, tvTenDichVu, tvTenKhuVuc, tvThoiGian, tvKhoangGia;
        Button btnNhanDon, btnTuChoi;

        DonChoViewHolder(@NonNull View itemView) {
            super(itemView);
            tvMaDon = itemView.findViewById(R.id.tvMaDon);
            tvTenDichVu = itemView.findViewById(R.id.tvTenDichVu);
            tvTenKhuVuc = itemView.findViewById(R.id.tvTenKhuVuc);
            tvThoiGian = itemView.findViewById(R.id.tvThoiGian);
            tvKhoangGia = itemView.findViewById(R.id.tvKhoangGia);
            btnNhanDon = itemView.findViewById(R.id.btnNhanDon);
            btnTuChoi = itemView.findViewById(R.id.btnTuChoi);
        }
    }
}