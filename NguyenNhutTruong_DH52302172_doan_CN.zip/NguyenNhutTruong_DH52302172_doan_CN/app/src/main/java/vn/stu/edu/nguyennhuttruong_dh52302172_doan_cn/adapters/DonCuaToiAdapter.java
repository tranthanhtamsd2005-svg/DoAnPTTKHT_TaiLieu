package vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.R;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.models.DonHang;

public class DonCuaToiAdapter extends RecyclerView.Adapter<DonCuaToiAdapter.ViewHolder> {

    public interface OnChonDonListener {
        void onXemChiTiet(DonHang don);
    }

    private final List<DonHang> danhSach = new ArrayList<>();
    private final OnChonDonListener listener;

    public DonCuaToiAdapter(OnChonDonListener listener) {
        this.listener = listener;
    }

    public void capNhatDanhSach(List<DonHang> dsMoi) {
        danhSach.clear();
        if (dsMoi != null) {
            danhSach.addAll(dsMoi);
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_don_cua_toi, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        DonHang don = danhSach.get(position);
        h.tvMaDon.setText("Mã đơn: " + don.getMaDon());
        h.tvTrangThai.setText(dinhDangTrangThai(don.getTrangThai()));

        String tenDv = don.getTenDichVu() != null ? don.getTenDichVu() : don.getMaDichVu();
        h.tvDichVu.setText(tenDv);

        String diaChi = don.getDiaChiChiTiet() != null ? don.getDiaChiChiTiet() : don.getTenKhuVuc();
        h.tvDiaChi.setText("Địa chỉ: " + (diaChi != null ? diaChi : "--"));

        String tg = don.getGioHen() != null ? "Hẹn lúc: " + don.getGioHen()
                : (don.getNgayNhan() != null ? "Nhận lúc: " + don.getNgayNhan() : "Đặt ngay");
        h.tvThoiGian.setText(tg);

        h.btnXemChiTiet.setOnClickListener(v -> listener.onXemChiTiet(don));
        h.itemView.setOnClickListener(v -> listener.onXemChiTiet(don));
    }

    @Override
    public int getItemCount() {
        return danhSach.size();
    }

    private String dinhDangTrangThai(String tt) {
        if (tt == null) return "--";
        switch (tt) {
            case "DA_NHAN": return "Đã nhận";
            case "DANG_LAM": return "Đang làm";
            case "HOAN_THANH": return "Hoàn thành";
            case "DA_HUY": return "Đã hủy";
            default: return tt;
        }
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvMaDon, tvTrangThai, tvDichVu, tvDiaChi, tvThoiGian;
        Button btnXemChiTiet;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvMaDon = itemView.findViewById(R.id.tvItemMaDon);
            tvTrangThai = itemView.findViewById(R.id.tvItemTrangThai);
            tvDichVu = itemView.findViewById(R.id.tvItemDichVu);
            tvDiaChi = itemView.findViewById(R.id.tvItemDiaChi);
            tvThoiGian = itemView.findViewById(R.id.tvItemThoiGian);
            btnXemChiTiet = itemView.findViewById(R.id.btnXemChiTiet);
        }
    }
}