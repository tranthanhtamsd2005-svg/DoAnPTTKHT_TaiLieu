package vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.models;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

public class DonHang implements Serializable {
    private static final long serialVersionUID = 1L;

    private String maDon;  // don_hang.ma_don varchar(24), khoa chinh
    private String maKhach;  // varchar(20), khoa ngoai -> tai_khoan
    private String maDichVu;  // varchar(20), khoa ngoai -> dich_vu
    private String maKhuVuc;  // varchar(20), khoa ngoai -> khu_vuc
    private String maTho;  // varchar(20), NULL khi don con 'Cho nhan'
    private String maYeuCau;  // varchar(100), ma chong tao don trung
    private String diaChiChiTiet;  // text
    private Double viDo;  // numeric(9,6)
    private Double kinhDo;  // numeric(9,6)
    private String moTa;  // text
    private String hinhThucDat;  // varchar(12), dat ngay / hen gio
    private String gioHen;  // timestamptz, ISO-8601, NULL neu dat ngay
    private String trangThai;  // varchar(20), trang thai don cot loi
    private BigDecimal giaThapNhatApDung;  // numeric(14,2), tien
    private BigDecimal giaCaoNhatApDung;  // numeric(14,2), tien
    private Integer baoHanhGioApDung;  // integer
    private Integer phanAnhGioApDung;  // integer
    private String hanBaoHanh;  // timestamptz
    private String ngayTao;  // timestamptz
    private String ngayNhan;  // timestamptz, NULL truoc khi co tho nhan
    private String ngayBatDauLam;  // timestamptz
    private String ngayHoanThanh;  // timestamptz
    private String ngayHuy;  // timestamptz
    private String lyDoHuy;  // text
    private String tenDichVu;  // [JOIN] dich_vu.ten_dich_vu
    private String tenKhuVuc;  // [JOIN] khu_vuc.ten_khu_vuc
    private String tenKhach;
    private String tienDo;
    private String gioDuKienDen;
    private List<LichSuTrangThai> lichSuTrangThai;
    private ThanhToanTrucTiep thanhToan;
    private DoiSoatTho doiSoat;

    public DonHang() {
    }

    public DonHang(String maDon, String maKhach, String maDichVu, String maKhuVuc, String maTho,
                   String maYeuCau, String diaChiChiTiet, Double viDo, Double kinhDo, String moTa,
                   String hinhThucDat, String gioHen, String trangThai,
                   BigDecimal giaThapNhatApDung, BigDecimal giaCaoNhatApDung,
                   Integer baoHanhGioApDung, Integer phanAnhGioApDung, String hanBaoHanh,
                   String ngayTao, String ngayNhan, String ngayBatDauLam, String ngayHoanThanh,
                   String ngayHuy, String lyDoHuy, String tenDichVu, String tenKhuVuc, String tenKhach) {
        this.maDon = maDon;
        this.maKhach = maKhach;
        this.maDichVu = maDichVu;
        this.maKhuVuc = maKhuVuc;
        this.maTho = maTho;
        this.maYeuCau = maYeuCau;
        this.diaChiChiTiet = diaChiChiTiet;
        this.viDo = viDo;
        this.kinhDo = kinhDo;
        this.moTa = moTa;
        this.hinhThucDat = hinhThucDat;
        this.gioHen = gioHen;
        this.trangThai = trangThai;
        this.giaThapNhatApDung = giaThapNhatApDung;
        this.giaCaoNhatApDung = giaCaoNhatApDung;
        this.baoHanhGioApDung = baoHanhGioApDung;
        this.phanAnhGioApDung = phanAnhGioApDung;
        this.hanBaoHanh = hanBaoHanh;
        this.ngayTao = ngayTao;
        this.ngayNhan = ngayNhan;
        this.ngayBatDauLam = ngayBatDauLam;
        this.ngayHoanThanh = ngayHoanThanh;
        this.ngayHuy = ngayHuy;
        this.lyDoHuy = lyDoHuy;
        this.tenDichVu = tenDichVu;
        this.tenKhuVuc = tenKhuVuc;
        this.tenKhach = tenKhach;
    }

    public static class LichSuTrangThai implements Serializable {
        private static final long serialVersionUID = 1L;
        private String trangThaiCu;
        private String trangThaiMoi;
        private String maNguoiThucHien;
        private String ghiChu;
        private String ngayThayDoi;

        public String getTrangThaiCu() { return trangThaiCu; }
        public String getTrangThaiMoi() { return trangThaiMoi; }
        public String getMaNguoiThucHien() { return maNguoiThucHien; }
        public String getGhiChu() { return ghiChu; }
        public String getNgayThayDoi() { return ngayThayDoi; }
    }

    public static class ThanhToanTrucTiep implements Serializable {
        private static final long serialVersionUID = 1L;
        private String hinhThuc;
        private double soTienKhaiBao;
        private String trangThai;
        private String ghiChu;
        private String ngayKhaiBao;

        public String getHinhThuc() { return hinhThuc; }
        public double getSoTienKhaiBao() { return soTienKhaiBao; }
        public String getTrangThai() { return trangThai; }
        public String getGhiChu() { return ghiChu; }
        public String getNgayKhaiBao() { return ngayKhaiBao; }
    }

    public static class DoiSoatTho implements Serializable {
        private static final long serialVersionUID = 1L;
        private double soTienPhaiNop;
        private String hanNop;
        private String ngayThoBaoNop;
        private String trangThai;
        private String ghiChu;
        private boolean quaHan;

        public double getSoTienPhaiNop() { return soTienPhaiNop; }
        public String getHanNop() { return hanNop; }
        public String getNgayThoBaoNop() { return ngayThoBaoNop; }
        public String getTrangThai() { return trangThai; }
        public String getGhiChu() { return ghiChu; }
        public boolean isQuaHan() { return quaHan; }
    }

    public String getMaDon() { return maDon; }
    public void setMaDon(String maDon) { this.maDon = maDon; }

    public String getMaKhach() { return maKhach; }
    public void setMaKhach(String maKhach) { this.maKhach = maKhach; }

    public String getMaDichVu() { return maDichVu; }
    public void setMaDichVu(String maDichVu) { this.maDichVu = maDichVu; }

    public String getMaKhuVuc() { return maKhuVuc; }
    public void setMaKhuVuc(String maKhuVuc) { this.maKhuVuc = maKhuVuc; }

    public String getMaTho() { return maTho; }
    public void setMaTho(String maTho) { this.maTho = maTho; }

    public String getMaYeuCau() { return maYeuCau; }
    public void setMaYeuCau(String maYeuCau) { this.maYeuCau = maYeuCau; }

    public String getDiaChiChiTiet() { return diaChiChiTiet; }
    public void setDiaChiChiTiet(String diaChiChiTiet) { this.diaChiChiTiet = diaChiChiTiet; }

    public Double getViDo() { return viDo; }
    public void setViDo(Double viDo) { this.viDo = viDo; }

    public Double getKinhDo() { return kinhDo; }
    public void setKinhDo(Double kinhDo) { this.kinhDo = kinhDo; }

    public String getMoTa() { return moTa; }
    public void setMoTa(String moTa) { this.moTa = moTa; }

    public String getHinhThucDat() { return hinhThucDat; }
    public void setHinhThucDat(String hinhThucDat) { this.hinhThucDat = hinhThucDat; }

    public String getGioHen() { return gioHen; }
    public void setGioHen(String gioHen) { this.gioHen = gioHen; }

    public String getTrangThai() { return trangThai; }
    public void setTrangThai(String trangThai) { this.trangThai = trangThai; }

    public BigDecimal getGiaThapNhatApDung() { return giaThapNhatApDung; }
    public void setGiaThapNhatApDung(BigDecimal giaThapNhatApDung) { this.giaThapNhatApDung = giaThapNhatApDung; }

    public BigDecimal getGiaCaoNhatApDung() { return giaCaoNhatApDung; }
    public void setGiaCaoNhatApDung(BigDecimal giaCaoNhatApDung) { this.giaCaoNhatApDung = giaCaoNhatApDung; }

    public Integer getBaoHanhGioApDung() { return baoHanhGioApDung; }
    public void setBaoHanhGioApDung(Integer baoHanhGioApDung) { this.baoHanhGioApDung = baoHanhGioApDung; }

    public Integer getPhanAnhGioApDung() { return phanAnhGioApDung; }
    public void setPhanAnhGioApDung(Integer phanAnhGioApDung) { this.phanAnhGioApDung = phanAnhGioApDung; }

    public String getHanBaoHanh() { return hanBaoHanh; }
    public void setHanBaoHanh(String hanBaoHanh) { this.hanBaoHanh = hanBaoHanh; }

    public String getNgayTao() { return ngayTao; }
    public void setNgayTao(String ngayTao) { this.ngayTao = ngayTao; }

    public String getNgayNhan() { return ngayNhan; }
    public void setNgayNhan(String ngayNhan) { this.ngayNhan = ngayNhan; }

    public String getNgayBatDauLam() { return ngayBatDauLam; }
    public void setNgayBatDauLam(String ngayBatDauLam) { this.ngayBatDauLam = ngayBatDauLam; }

    public String getNgayHoanThanh() { return ngayHoanThanh; }
    public void setNgayHoanThanh(String ngayHoanThanh) { this.ngayHoanThanh = ngayHoanThanh; }

    public String getNgayHuy() { return ngayHuy; }
    public void setNgayHuy(String ngayHuy) { this.ngayHuy = ngayHuy; }

    public String getLyDoHuy() { return lyDoHuy; }
    public void setLyDoHuy(String lyDoHuy) { this.lyDoHuy = lyDoHuy; }

    public String getTenDichVu() { return tenDichVu; }
    public void setTenDichVu(String tenDichVu) { this.tenDichVu = tenDichVu; }

    public String getTenKhuVuc() { return tenKhuVuc; }
    public void setTenKhuVuc(String tenKhuVuc) { this.tenKhuVuc = tenKhuVuc; }

    public String getTenKhach() { return tenKhach; }
    public void setTenKhach(String tenKhach) { this.tenKhach = tenKhach; }

    public String getTienDo() { return tienDo; }
    public void setTienDo(String tienDo) { this.tienDo = tienDo; }

    public String getGioDuKienDen() { return gioDuKienDen; }
    public void setGioDuKienDen(String gioDuKienDen) { this.gioDuKienDen = gioDuKienDen; }

    public List<LichSuTrangThai> getLichSuTrangThai() { return lichSuTrangThai; }
    public void setLichSuTrangThai(List<LichSuTrangThai> lichSuTrangThai) { this.lichSuTrangThai = lichSuTrangThai; }

    public ThanhToanTrucTiep getThanhToan() { return thanhToan; }
    public void setThanhToan(ThanhToanTrucTiep thanhToan) { this.thanhToan = thanhToan; }

    public DoiSoatTho getDoiSoat() { return doiSoat; }
    public void setDoiSoat(DoiSoatTho doiSoat) { this.doiSoat = doiSoat; }

    @Override
    public String toString() {
        return "DonHang{" +
                "maDon='" + maDon + '\'' +
                ", maKhach='" + maKhach + '\'' +
                ", maDichVu='" + maDichVu + '\'' +
                ", maKhuVuc='" + maKhuVuc + '\'' +
                ", maTho='" + maTho + '\'' +
                ", trangThai='" + trangThai + '\'' +
                ", tienDo='" + tienDo + '\'' +
                ", tenDichVu='" + tenDichVu + '\'' +
                ", tenKhuVuc='" + tenKhuVuc + '\'' +
                ", tenKhach='" + tenKhach + '\'' +
                '}';
    }
}