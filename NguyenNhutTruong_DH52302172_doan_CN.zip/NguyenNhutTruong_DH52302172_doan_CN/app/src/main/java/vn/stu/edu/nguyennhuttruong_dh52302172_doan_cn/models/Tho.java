package vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.models;

import java.io.Serializable;
import java.util.List;

public class Tho implements Serializable {
    private static final long serialVersionUID = 1L;

    private String maTho;  // ho_so_tho.ma_tho = tai_khoan.ma_tai_khoan, varchar(20)
    private String hoTen;  // tai_khoan.ho_ten varchar(120)
    private String soDienThoai;  // tai_khoan.so_dien_thoai varchar(20)
    private String email;  // tai_khoan.email varchar(255)
    private String anhDaiDien;  // tai_khoan.anh_dai_dien text (URL)
    private String trangThaiTaiKhoan;  // tai_khoan.trang_thai varchar(15)
    private String duongDanCccd;  // ho_so_tho.duong_dan_cccd text (URL)
    private String duongDanChungChiNghe;  // ho_so_tho.duong_dan_chung_chi_nghe text (URL)
    private String trangThaiDuyet;  // ho_so_tho.trang_thai_duyet varchar(20)
    private String lyDoTuChoi;  // ho_so_tho.ly_do_tu_choi text, NULL neu chua bi tu choi
    private boolean trangThaiSanSang;  // ho_so_tho.trang_thai_san_sang boolean
    private String ngayDuyet;  // ho_so_tho.ngay_duyet timestamptz
    private String ngayCapNhat;  // ho_so_tho.ngay_cap_nhat timestamptz
    private List<String> danhSachMaDichVu;  // [bang ky_nang_tho] cac ma_dich_vu cua tho
    private List<String> danhSachMaKhuVuc;

    public Tho(String maTho, String hoTen, String soDienThoai, String email, String anhDaiDien, String trangThaiTaiKhoan, String duongDanCccd, String duongDanChungChiNghe, String trangThaiDuyet, String lyDoTuChoi, boolean trangThaiSanSang, String ngayDuyet, String ngayCapNhat, List<String> danhSachMaDichVu, List<String> danhSachMaKhuVuc) {
        this.maTho = maTho;
        this.hoTen = hoTen;
        this.soDienThoai = soDienThoai;
        this.email = email;
        this.anhDaiDien = anhDaiDien;
        this.trangThaiTaiKhoan = trangThaiTaiKhoan;
        this.duongDanCccd = duongDanCccd;
        this.duongDanChungChiNghe = duongDanChungChiNghe;
        this.trangThaiDuyet = trangThaiDuyet;
        this.lyDoTuChoi = lyDoTuChoi;
        this.trangThaiSanSang = trangThaiSanSang;
        this.ngayDuyet = ngayDuyet;
        this.ngayCapNhat = ngayCapNhat;
        this.danhSachMaDichVu = danhSachMaDichVu;
        this.danhSachMaKhuVuc = danhSachMaKhuVuc;
    }

    public Tho() {
    }

    public String getMaTho() {
        return maTho;
    }

    public void setMaTho(String maTho) {
        this.maTho = maTho;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getSoDienThoai() {
        return soDienThoai;
    }

    public void setSoDienThoai(String soDienThoai) {
        this.soDienThoai = soDienThoai;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAnhDaiDien() {
        return anhDaiDien;
    }

    public void setAnhDaiDien(String anhDaiDien) {
        this.anhDaiDien = anhDaiDien;
    }

    public String getTrangThaiTaiKhoan() {
        return trangThaiTaiKhoan;
    }

    public void setTrangThaiTaiKhoan(String trangThaiTaiKhoan) {
        this.trangThaiTaiKhoan = trangThaiTaiKhoan;
    }

    public String getDuongDanCccd() {
        return duongDanCccd;
    }

    public void setDuongDanCccd(String duongDanCccd) {
        this.duongDanCccd = duongDanCccd;
    }

    public String getDuongDanChungChiNghe() {
        return duongDanChungChiNghe;
    }

    public void setDuongDanChungChiNghe(String duongDanChungChiNghe) {
        this.duongDanChungChiNghe = duongDanChungChiNghe;
    }

    public String getTrangThaiDuyet() {
        return trangThaiDuyet;
    }

    public void setTrangThaiDuyet(String trangThaiDuyet) {
        this.trangThaiDuyet = trangThaiDuyet;
    }

    public String getLyDoTuChoi() {
        return lyDoTuChoi;
    }

    public void setLyDoTuChoi(String lyDoTuChoi) {
        this.lyDoTuChoi = lyDoTuChoi;
    }

    public boolean isTrangThaiSanSang() {
        return trangThaiSanSang;
    }

    public void setTrangThaiSanSang(boolean trangThaiSanSang) {
        this.trangThaiSanSang = trangThaiSanSang;
    }

    public String getNgayDuyet() {
        return ngayDuyet;
    }

    public void setNgayDuyet(String ngayDuyet) {
        this.ngayDuyet = ngayDuyet;
    }

    public String getNgayCapNhat() {
        return ngayCapNhat;
    }

    public void setNgayCapNhat(String ngayCapNhat) {
        this.ngayCapNhat = ngayCapNhat;
    }

    public List<String> getDanhSachMaDichVu() {
        return danhSachMaDichVu;
    }

    public void setDanhSachMaDichVu(List<String> danhSachMaDichVu) {
        this.danhSachMaDichVu = danhSachMaDichVu;
    }

    public List<String> getDanhSachMaKhuVuc() {
        return danhSachMaKhuVuc;
    }

    public void setDanhSachMaKhuVuc(List<String> danhSachMaKhuVuc) {
        this.danhSachMaKhuVuc = danhSachMaKhuVuc;
    }

    @Override
    public String toString() {
        return "Tho{" +
                "maTho='" + maTho + '\'' +
                ", hoTen='" + hoTen + '\'' +
                ", soDienThoai='" + soDienThoai + '\'' +
                ", email='" + email + '\'' +
                ", anhDaiDien='" + anhDaiDien + '\'' +
                ", trangThaiTaiKhoan='" + trangThaiTaiKhoan + '\'' +
                ", duongDanCccd='" + duongDanCccd + '\'' +
                ", duongDanChungChiNghe='" + duongDanChungChiNghe + '\'' +
                ", trangThaiDuyet='" + trangThaiDuyet + '\'' +
                ", lyDoTuChoi='" + lyDoTuChoi + '\'' +
                ", trangThaiSanSang=" + trangThaiSanSang +
                ", ngayDuyet='" + ngayDuyet + '\'' +
                ", ngayCapNhat='" + ngayCapNhat + '\'' +
                ", danhSachMaDichVu=" + danhSachMaDichVu +
                ", danhSachMaKhuVuc=" + danhSachMaKhuVuc +
                '}';
    }
}

