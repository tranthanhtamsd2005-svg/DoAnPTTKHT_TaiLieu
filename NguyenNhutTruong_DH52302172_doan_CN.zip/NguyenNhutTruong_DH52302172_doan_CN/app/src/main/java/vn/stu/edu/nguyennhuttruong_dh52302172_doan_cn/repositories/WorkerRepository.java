package vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.repositories;

import org.json.JSONObject;

import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.models.DonHang;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.models.Tho;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.utils.ApiService;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.utils.RetrofitClient;

public class WorkerRepository {
    public interface KetQua<T> { void thanhCong(T du); void loi(String tb); }

    private final ApiService api = RetrofitClient.getApiService();

    private <T> void goi(Call<T> call, KetQua<T> cb) {
        call.enqueue(new Callback<T>() {
            @Override
            public void onResponse(Call<T> c, Response<T> r) {
                if (r.isSuccessful()) cb.thanhCong(r.body());
                else cb.loi(docThongBaoLoi(r, "Máy chủ trả lỗi"));
            }

            @Override
            public void onFailure(Call<T> c, Throwable t) {
                cb.loi("Không kết nối được máy chủ: " + t.getMessage());
            }
        });
    }

    private void goiThongBao(Call<Map<String, Object>> call, String thanhCongMsg, String loiMacDinh, KetQua<String> cb) {
        call.enqueue(new Callback<Map<String, Object>>() {
            @Override
            public void onResponse(Call<Map<String, Object>> c, Response<Map<String, Object>> r) {
                if (r.isSuccessful()) {
                    cb.thanhCong(thanhCongMsg);
                } else {
                    cb.loi(docThongBaoLoi(r, loiMacDinh));
                }
            }

            @Override
            public void onFailure(Call<Map<String, Object>> c, Throwable t) {
                cb.loi("Mất kết nối mạng: " + t.getMessage());
            }
        });
    }

    private String docThongBaoLoi(Response<?> res, String macDinh) {
        try {
            if (res.errorBody() != null) {
                String raw = res.errorBody().string();
                JSONObject obj = new JSONObject(raw);
                if (obj.has("message")) {
                    return obj.getString("message") + " (HTTP " + res.code() + ")";
                }
            }
        } catch (Exception ignored) {
        }
        return macDinh + " (HTTP " + res.code() + ")";
    }

    public void donCho(String maTho, KetQua<List<DonHang>> cb) {
        goi(api.donCho(maTho), cb);
    }

    public void sanSang(String maTho, boolean v, KetQua<Map<String, Object>> cb) {
        goi(api.sanSang(maTho, Map.of("san_sang", v)), cb);
    }

    public void hoSo(String maTho, KetQua<Tho> cb) {
        goi(api.hoSo(maTho), cb);
    }

    public void donCuaToi(String maTho, String trangThai, KetQua<List<DonHang>> cb) {
        goi(api.donCuaToi(maTho, trangThai), cb);
    }

    public void chiTietDon(String maTho, String maDon, KetQua<DonHang> cb) {
        goi(api.chiTietDon(maTho, maDon), cb);
    }

    public void batDauLam(String maTho, String maDon, KetQua<String> cb) {
        goiThongBao(api.batDauLam(maTho, maDon),
                "Đã chuyển sang trạng thái Đang làm", "Không thể bắt đầu làm", cb);
    }

    public void hoanThanhDon(String maTho, String maDon, KetQua<String> cb) {
        goiThongBao(api.hoanThanhDon(maTho, maDon),
                "Đã hoàn thành đơn hàng", "Không thể hoàn thành đơn", cb);
    }

    public void capNhatHanhTrinh(String maTho, String maDon, String tienDo, KetQua<String> cb) {
        goiThongBao(api.capNhatHanhTrinh(maTho, maDon, tienDo),
                "Đã cập nhật hành trình", "Không thể cập nhật hành trình", cb);
    }

    public void capNhatEta(String maTho, String maDon, int soPhut, String lyDo, KetQua<String> cb) {
        goiThongBao(api.capNhatEta(maTho, maDon, soPhut, lyDo),
                "Đã cập nhật giờ dự kiến đến", "Không thể cập nhật ETA", cb);
    }

    public void khaiBaoThanhToan(String maTho, String maDon, String hinhThuc,
                                 double soTien, String ghiChu, KetQua<String> cb) {
        goiThongBao(api.khaiBaoThanhToan(maTho, maDon, hinhThuc, soTien, ghiChu),
                "Đã ghi nhận thanh toán trực tiếp", "Không thể ghi nhận thanh toán", cb);
    }

    public void baoNopDoiSoat(String maTho, String maDon, String ghiChu, KetQua<String> cb) {
        goiThongBao(api.baoNopDoiSoat(maTho, maDon, ghiChu),
                "Đã báo nộp đối soát thành công", "Không thể báo nộp đối soát", cb);
    }
}