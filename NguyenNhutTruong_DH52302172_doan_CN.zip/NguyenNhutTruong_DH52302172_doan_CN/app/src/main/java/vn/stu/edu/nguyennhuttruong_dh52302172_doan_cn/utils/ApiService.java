package vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.utils;

import java.util.List;
import java.util.Map;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Query;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.models.DonHang;
import vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.models.Tho;

public interface ApiService {
    @POST("api/tho/login")
    Call<Map<String, Object>> login(@Body Map<String, String> body);
    @GET("api/tho/don-cho")
    Call<List<DonHang>> donCho(@Query("ma_tho") String maTho);

    @PUT("api/tho/san-sang")
    Call<Map<String, Object>> sanSang(@Query("ma_tho") String maTho, @Body Map<String, Object> body);
    @GET("api/tho/ho-so")
    Call<Tho> hoSo(@Query("ma_tho") String maTho);
    @POST("api/tho/thanh-toan")
    Call<Map<String, Object>> khaiBaoThanhToan(
            @Query("ma_tho") String maTho,
            @Query("ma_don") String maDon,
            @Query("hinh_thuc") String hinhThuc,
            @Query("so_tien") double soTien,
            @Query("ghi_chu") String ghiChu
    );

    @POST("api/tho/bao-nop-doi-soat")
    Call<Map<String, Object>> baoNopDoiSoat(
            @Query("ma_tho") String maTho,
            @Query("ma_don") String maDon,
            @Query("ghi_chu") String ghiChu
    );
    @GET("api/tho/don-cua-toi")
    Call<List<DonHang>> donCuaToi(
            @Query("ma_tho") String maTho,
            @Query("trang_thai") String trangThai
    );

    @GET("api/tho/chi-tiet-don")
    Call<DonHang> chiTietDon(
            @Query("ma_tho") String maTho,
            @Query("ma_don") String maDon
    );

    @POST("api/tho/bat-dau-lam")
    Call<Map<String, Object>> batDauLam(
            @Query("ma_tho") String maTho,
            @Query("ma_don") String maDon
    );

    @POST("api/tho/hoan-thanh")
    Call<Map<String, Object>> hoanThanhDon(
            @Query("ma_tho") String maTho,
            @Query("ma_don") String maDon
    );

    @POST("api/tho/hanh-trinh")
    Call<Map<String, Object>> capNhatHanhTrinh(
            @Query("ma_tho") String maTho,
            @Query("ma_don") String maDon,
            @Query("tien_do") String tienDo
    );

    @POST("api/tho/eta")
    Call<Map<String, Object>> capNhatEta(
            @Query("ma_tho") String maTho,
            @Query("ma_don") String maDon,
            @Query("so_phut") int soPhut,
            @Query("ly_do") String lyDo
    );
}