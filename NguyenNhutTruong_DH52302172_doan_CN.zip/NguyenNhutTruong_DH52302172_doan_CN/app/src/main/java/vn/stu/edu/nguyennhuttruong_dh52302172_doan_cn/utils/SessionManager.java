package vn.stu.edu.nguyennhuttruong_dh52302172_doan_cn.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    private static final String PREF_NAME = "WorkerSession";
    private static final String KEY_MA_THO = "ma_tho";
    private SharedPreferences pref;
    private SharedPreferences.Editor editor;

    public SessionManager(Context context) {
        pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = pref.edit();
    }

    public void saveMaTho(String maTho) {
        editor.putString(KEY_MA_THO, maTho);
        editor.apply();
    }

    public String getMaTho() {
        return pref.getString(KEY_MA_THO, null);
    }

    public void logout() {
        editor.clear();
        editor.apply();
    }
}